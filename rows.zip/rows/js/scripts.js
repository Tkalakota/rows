// Scripts for rows.html

$('.animate-on-mouseenter').on('mouseenter', function() {
	$(this).toggleClass("animated zoomIn");
});